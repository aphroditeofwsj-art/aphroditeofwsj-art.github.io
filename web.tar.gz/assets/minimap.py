import pygame
from settings import *
from support import get_font

class Minimap:
    def __init__(self, level):
        self.display_surface = pygame.display.get_surface()
        self.level = level
        self.width = 200
        self.height = 150
        self.margin = 10
        self.position = WIDTH - self.width - self.margin, self.margin
        self.scale = 8
        self.fullscreen = False
        self.fullscreen_scale = 4
        self.map_layout = self.load_map_layout()
        self.bg_color = (20, 20, 30, 180)
        self.wall_color = (100, 100, 100)
        self.floor_color = (60, 60, 80)
        self.player_color = (0, 255, 0)
        self.enemy_color = (255, 0, 0)
        self.grass_color = (40, 80, 40)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen

    def load_map_layout(self):
        from support import import_csv_layout
        layouts = {'boundary': import_csv_layout('map/map_FloorBlocks.csv'), 'grass': import_csv_layout('map/map_Grass.csv'), 'object': import_csv_layout('map/map_Objects.csv')}
        return layouts

    def draw_tile(self, surface, x, y, color, scale):
        pygame.draw.rect(surface, color, (x, y, scale, scale))

    def draw_minimap(self):
        map_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        map_surface.fill((20, 20, 30, 180))
        player_x = self.level.player.rect.centerx // TILESIZE
        player_y = self.level.player.rect.centery // TILESIZE
        tiles_x = self.width // self.scale
        tiles_y = self.height // self.scale
        start_x = player_x - tiles_x // 2
        start_y = player_y - tiles_y // 2
        boundary_layout = self.map_layout.get('boundary', [])
        for row_idx, row in enumerate(boundary_layout):
            for col_idx, col in enumerate(row):
                if start_x <= col_idx < start_x + tiles_x:
                    if start_y <= row_idx < start_y + tiles_y:
                        screen_x = (col_idx - start_x) * self.scale
                        screen_y = (row_idx - start_y) * self.scale
                        if col != '-1':
                            self.draw_tile(map_surface, screen_x, screen_y, self.wall_color, self.scale)
                        else:
                            self.draw_tile(map_surface, screen_x, screen_y, self.floor_color, self.scale)
        grass_layout = self.map_layout.get('grass', [])
        for row_idx, row in enumerate(grass_layout):
            for col_idx, col in enumerate(row):
                if start_x <= col_idx < start_x + tiles_x:
                    if start_y <= row_idx < start_y + tiles_y:
                        screen_x = (col_idx - start_x) * self.scale
                        screen_y = (row_idx - start_y) * self.scale
                        if col != '-1':
                            self.draw_tile(map_surface, screen_x, screen_y, self.grass_color, self.scale)
        for sprite in self.level.visible_sprites:
            if not hasattr(sprite, 'sprite_type'):
                continue
            if not sprite.sprite_type == 'enemy':
                continue
            enemy_x = sprite.rect.centerx // TILESIZE
            enemy_y = sprite.rect.centery // TILESIZE
            if start_x <= enemy_x < start_x + tiles_x and start_y <= enemy_y < start_y + tiles_y:
                screen_x = (enemy_x - start_x) * self.scale + self.scale // 2
                screen_y = (enemy_y - start_y) * self.scale + self.scale // 2
                pygame.draw.circle(map_surface, self.enemy_color, (int(screen_x), int(screen_y)), self.scale // 2)
        player_screen_x = tiles_x // 2 * self.scale + self.scale // 2
        player_screen_y = tiles_y // 2 * self.scale + self.scale // 2
        pygame.draw.circle(map_surface, self.player_color, (int(player_screen_x), int(player_screen_y)), self.scale // 2 + 1)
        pygame.draw.rect(map_surface, UI_BORDER_COLOR_ACTIVE, (0, 0, self.width, self.height), 2)
        self.display_surface.blit(map_surface, self.position)

    def draw_fullscreen_map(self):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200))
        self.display_surface.blit(overlay, (0, 0))
        boundary_layout = self.map_layout.get('boundary', [])
        map_height = len(boundary_layout)
        map_width = len(boundary_layout[0]) if map_height > 0 else 0
        total_width = map_width * self.fullscreen_scale
        total_height = map_height * self.fullscreen_scale
        start_x = (WIDTH - total_width) // 2
        start_y = (HEIGHT - total_height) // 2
        map_surface = pygame.Surface((total_width, total_height), pygame.SRCALPHA)
        map_surface.fill((30, 30, 40))
        for row_idx, row in enumerate(boundary_layout):
            for col_idx, col in enumerate(row):
                screen_x = col_idx * self.fullscreen_scale
                screen_y = row_idx * self.fullscreen_scale
                if col != '-1':
                    self.draw_tile(map_surface, screen_x, screen_y, self.wall_color, self.fullscreen_scale)
                else:
                    self.draw_tile(map_surface, screen_x, screen_y, self.floor_color, self.fullscreen_scale)
        grass_layout = self.map_layout.get('grass', [])
        for row_idx, row in enumerate(grass_layout):
            for col_idx, col in enumerate(row):
                if col != '-1':
                    screen_x = col_idx * self.fullscreen_scale
                    screen_y = row_idx * self.fullscreen_scale
                    self.draw_tile(map_surface, screen_x, screen_y, self.grass_color, self.fullscreen_scale)
        for sprite in self.level.visible_sprites:
            if not hasattr(sprite, 'sprite_type'):
                continue
            if not sprite.sprite_type == 'enemy':
                continue
            enemy_x = sprite.rect.centerx // TILESIZE
            enemy_y = sprite.rect.centery // TILESIZE
            screen_x = enemy_x * self.fullscreen_scale + self.fullscreen_scale // 2
            screen_y = enemy_y * self.fullscreen_scale + self.fullscreen_scale // 2
            pygame.draw.circle(map_surface, self.enemy_color, (int(screen_x), int(screen_y)), self.fullscreen_scale)
        player_x = self.level.player.rect.centerx // TILESIZE
        player_y = self.level.player.rect.centery // TILESIZE
        player_screen_x = player_x * self.fullscreen_scale + self.fullscreen_scale // 2
        player_screen_y = player_y * self.fullscreen_scale + self.fullscreen_scale // 2
        pygame.draw.circle(map_surface, self.player_color, (int(player_screen_x), int(player_screen_y)), self.fullscreen_scale + 1)
        pygame.draw.rect(map_surface, UI_BORDER_COLOR_ACTIVE, (0, 0, total_width, total_height), 2)
        self.display_surface.blit(map_surface, (start_x, start_y))
        font = get_font(20)
        hint_text = '按 M 关闭地图'
        hint_surf = font.render(hint_text, True, TEXT_COLOR)
        hint_rect = hint_surf.get_rect(bottomcenter=(WIDTH // 2, HEIGHT - 20))
        self.display_surface.blit(hint_surf, hint_rect)

    def draw(self):
        if self.fullscreen:
            self.draw_fullscreen_map()
            return
        self.draw_minimap()


