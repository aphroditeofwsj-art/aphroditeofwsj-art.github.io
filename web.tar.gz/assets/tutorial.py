import pygame
from settings import *
from support import get_font

class Tutorial:
    def __init__(self):
        self.display_surface = pygame.display.get_surface()
        self.font = get_font(UI_FONT_SIZE)
        self.font_large = get_font(UI_FONT_SIZE * 2)
        self.font_title = get_font(UI_FONT_SIZE * 3)
        self.active = True
        self.current_step = 0
        self.total_steps = 7
        self.tutorials = [{'title': '欢迎来到海拉鲁', 'text': '欢迎，年轻的勇士！按下任意键开始教程', 'key_hint': None}, {'title': '移动', 'text': '使用 WASD 或 方向键 移动角色', 'key_hint': 'WASD / 方向键'}, {'title': '攻击', 'text': '按 空格键 使用武器攻击敌人', 'key_hint': '空格键'}, {'title': '魔法', 'text': '按 Ctrl 使用魔法（火焰或治疗）', 'key_hint': 'Ctrl'}, {'title': '切换武器', 'text': '按 Q 键 切换武器类型', 'key_hint': 'Q'}, {'title': '切换魔法', 'text': '按 E 键 切换魔法类型', 'key_hint': 'E'}, {'title': '商店', 'text': '按 G 键 打开商店，购买药水和装备', 'key_hint': 'G'}, {'title': '升级菜单', 'text': '按 M 键 打开升级菜单，提升属性', 'key_hint': 'M'}]
        self.start_time = pygame.time.get_ticks()
        self.display_duration = 3000
        self.alpha = 0
        self.alpha_direction = 15

    def next_step(self):
        self.current_step += 1
        if self.current_step >= len(self.tutorials):
            self.active = False
            return
        self.start_time = pygame.time.get_ticks()
        self.alpha = 0

    def skip(self):
        self.active = False
        print('✓ Tutorial skipped')

    def completed(self):
        return not self.active and self.current_step >= len(self.tutorials)

    def update(self):
        if not self.active:
            return
        current_time = pygame.time.get_ticks()
        elapsed = current_time - self.start_time
        if elapsed < 300:
            self.alpha = min(255, elapsed / 300 * 255)
            return
        if elapsed > self.display_duration - 300:
            self.alpha = max(0, (self.display_duration - elapsed) / 300 * 255)
            return
        self.alpha = 255

    def draw(self):
        if not self.active:
            return
        tutorial = self.tutorials[self.current_step]
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.display_surface.blit(overlay, (0, 0))
        box_width, box_height = 700, 250
        box_x = (WIDTH - box_width) // 2
        box_y = (HEIGHT - box_height) // 2
        box_rect = pygame.Rect(box_x, box_y, box_width, box_height)
        box_surf = pygame.Surface((box_width, box_height), pygame.SRCALPHA)
        box_surf.fill((30, 30, 30, 220))
        self.display_surface.blit(box_surf, (box_x, box_y))
        pygame.draw.rect(self.display_surface, UI_BORDER_COLOR_ACTIVE, box_rect, 4)
        title_surf = self.font_large.render(tutorial['title'], True, TEXT_COLOR)
        title_rect = title_surf.get_rect(midtop=(WIDTH // 2, box_y + 20))
        title_surf.set_alpha(self.alpha)
        self.display_surface.blit(title_surf, title_rect)
        text_surf = self.font.render(tutorial['text'], True, TEXT_COLOR)
        text_rect = text_surf.get_rect(center=(WIDTH // 2, box_y + 100))
        text_surf.set_alpha(self.alpha)
        self.display_surface.blit(text_surf, text_rect)
        if tutorial['key_hint']:
            key_surf = self.font.render(f'[{tutorial['key_hint']}]', True, UI_BORDER_COLOR_ACTIVE)
            key_rect = key_surf.get_rect(center=(WIDTH // 2, box_y + 150))
            key_surf.set_alpha(self.alpha)
            self.display_surface.blit(key_surf, key_rect)
        progress_text = f'{self.current_step + 1} / {len(self.tutorials)}'
        progress_surf = self.font.render(progress_text, True, TEXT_COLOR)
        progress_rect = progress_surf.get_rect(bottomright=(box_x + box_width - 20, box_y + box_height - 15))
        progress_surf.set_alpha(self.alpha)
        self.display_surface.blit(progress_surf, progress_rect)
        if self.current_step > 0:
            skip_text = '按 ESC 跳过教程'
            skip_surf = self.font.render(skip_text, True, (150, 150, 150))
            skip_rect = skip_surf.get_rect(center=(WIDTH // 2, box_y + box_height + 30))
            skip_surf.set_alpha(self.alpha)
            self.display_surface.blit(skip_surf, skip_rect)

    def handle_event(self, event):
        if not self.active:
            return False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.skip()
                return True
            self.next_step()
            return True
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.next_step()
            return True
        return False


