import pygame
from settings import *
from support import get_font

class Shop:
    def __init__(self, player):
        self.display_surface = pygame.display.get_surface()
        self.player = player
        self.font = get_font(UI_FONT_SIZE)
        self.font_large = get_font(UI_FONT_SIZE + 4)
        self.active = False
        self.current_villager = None
        self.selected_item = 0
        self.item_list = list(shop_items.keys())
        self.width = 600
        self.height = 400
        self.x = (WIDTH - self.width) // 2
        self.y = (HEIGHT - self.height) // 2

    def open(self, villager):
        print(f'[OK] Shop.open() called with villager: {villager.name}')
        self.active = True
        self.current_villager = villager
        self.selected_item = 0

    def close(self):
        print('[OK] Shop.close() called')
        self.active = False
        self.current_villager = None

    def handle_event(self, event):
        if not self.active:
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN and self.selected_item < len(self.item_list) - 1:
                self.selected_item += 1
                print(f'[OK] Selected item: {self.selected_item}')
                return
            if event.key == pygame.K_UP and self.selected_item > 0:
                self.selected_item -= 1
                print(f'[OK] Selected item: {self.selected_item}')
                return
            if event.key == pygame.K_SPACE:
                self.buy_selected()
                return
            if event.key == pygame.K_ESCAPE:
                self.close()

    def buy_selected(self):
        item_key = self.item_list[self.selected_item]
        item = shop_items[item_key]
        if self.player.gold >= item['price']:
            self.player.gold -= item['price']
            print('[OK] Bought {} for {} gold'.format(item['name'], item['price']))
            self.apply_item_effect(item)
            return
        print('[FAIL] Not enough gold')

    def apply_item_effect(self, item):
        if item['effect'] == 'heal':
            self.player.health = min(self.player.stats['health'], self.player.health + item['value'])
            return
        if item['effect'] == 'energy':
            self.player.energy = min(self.player.stats['energy'], self.player.energy + item['value'])

    def draw(self):
        if not self.active:
            return
        pygame.draw.rect(self.display_surface, UI_BG_COLOR, (self.x, self.y, self.width, self.height))
        pygame.draw.rect(self.display_surface, UI_BORDER_COLOR_ACTIVE, (self.x, self.y, self.width, self.height), 4)
        title_surf = self.font_large.render('商店', True, TEXT_COLOR)
        title_rect = title_surf.get_rect(midtop=(WIDTH // 2, self.y + 20))
        self.display_surface.blit(title_surf, title_rect)
        if self.current_villager:
            villager_surf = self.font.render(f'店主: {self.current_villager.name}', True, UI_BORDER_COLOR_ACTIVE)
            villager_rect = villager_surf.get_rect(midtop=(WIDTH // 2, self.y + 50))
            self.display_surface.blit(villager_surf, villager_rect)
        gold_surf = self.font.render(f'金币: {self.player.gold}', True, GOLD_COLOR)
        gold_rect = gold_surf.get_rect(topleft=(self.x + 20, self.y + 60))
        self.display_surface.blit(gold_surf, gold_rect)
        y_offset = 100
        for index, item_key in enumerate(self.item_list):
            item = shop_items[item_key]
            x = self.x + 50
            y = self.y + y_offset
            if index == self.selected_item:
                pygame.draw.rect(self.display_surface, UPGRADE_BG_COLOR_SELECTED, (x - 10, y - 5, self.width - 120, 30))
                name_color = TEXT_COLOR_SELECTED
                price_color = (110, 85, 0)
            else:
                name_color = TEXT_COLOR
                price_color = GOLD_COLOR
            name_surf = self.font.render(item['name'], True, name_color)
            self.display_surface.blit(name_surf, (x, y))
            price_surf = self.font.render('{} 金币'.format(item['price']), True, price_color)
            price_rect = price_surf.get_rect(right=self.x + self.width - 50, centery=y + 10)
            self.display_surface.blit(price_surf, price_rect)
            y_offset += 40
            continue
        control_surf = self.font.render('上下键选择 | 空格购买 | ESC关闭', True, (150, 150, 150))
        control_rect = control_surf.get_rect(midbottom=(WIDTH // 2, self.y + self.height - 20))
        self.display_surface.blit(control_surf, control_rect)

    def update(self):
        if self.active:
            self.draw()


