import pygame
import math
from settings import *
from random import randint

class Coin(pygame.sprite.Sprite):
    def __init__(self, pos, amount, groups):
        super().__init__(groups)
        self.sprite_type = 'coin'
        self.frames = []
        for i in range(4):
            surf = pygame.Surface((32, 32), pygame.SRCALPHA)
            pygame.draw.circle(surf, GOLD_COLOR, (16, 16), 14)
            pygame.draw.circle(surf, (255, 255, 200), (12, 12), 4)
            self.frames.append(surf)
        self.frame_index = 0
        self.animation_speed = 0.2
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect(center=pos)
        self.hitbox = self.rect.inflate(-10, -10)
        self.original_y = self.rect.y
        self.amount = amount
        self.bob_offset = 0
        self.bob_speed = 0.05
        self.bob_height = 5

    def animate(self):
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

    def update(self):
        self.animate()
        self.bob_offset += self.bob_speed
        self.rect.y = self.original_y + self.bob_height * math.sin(self.bob_offset)


class CoinManager:
    def __init__(self):
        self.coins = pygame.sprite.Group()

    def create_coin(self, pos, amount, groups):
        Coin(pos, amount, groups)

    def draw(self, surface):
        for coin in self.coins:
            surface.blit(coin.image, coin.rect)

    def update(self):
        self.coins.update()


