import pygame
from settings import *
from tile import Tile
from player import Player
from debug import debug
from support import *
from random import choice, randint
from weapon import Weapon
from ui import UI
from enemy import Enemy
from particles import AnimationPlayer
from magic import MagicPlayer
from upgrade import Upgrade
from tutorial import Tutorial
from minimap import Minimap
from coin import Coin
from fruit import Fruit
from shop_simple import Shop
from villager import Villager

class Level:
    def __init__(self):
        self.display_surface = pygame.display.get_surface()
        self.game_paused = False
        self.game_over = False
        self.game_won = False
        self.current_attack = None
        self.attack_sprites = pygame.sprite.Group()
        self.attackable_sprites = pygame.sprite.Group()
        self.coin_sprites = pygame.sprite.Group()
        self.fruit_sprites = pygame.sprite.Group()
        self.visible_sprites = YSortCameraGroup()
        self.obstacle_sprites = pygame.sprite.Group()
        self._preload_assets()
        self.total_enemies = 0
        self.enemies_killed = 0
        self.create_map()
        self.ui = UI()
        self.upgrade = Upgrade(self.player)
        self.animation_player = AnimationPlayer()
        self.magic_player = MagicPlayer(self.animation_player)
        self.tutorial = Tutorial()
        self.minimap = Minimap(self)
        self.shop = Shop(self.player)

    def _preload_assets(self):
        '''预加载所有UI图像和字体，防止每帧加载导致内存泄漏'''

        self.font_large = get_font(48)
        self.font_medium = get_font(28)
        self.font_small = get_font(24)
        self.death_scene_img = None
        self.death_text_img = None
        try:
            scene_path = RESOURCE_PATH / 'assets' / 'death_scene.png'
            if scene_path.exists():
                self.death_scene_img = pygame.image.load(str(scene_path)).convert()
                self.death_scene_img = pygame.transform.scale(self.death_scene_img, (WIDTH, HEIGHT))
        except Exception:
            self.death_scene_img = None
        try:
            text_path = RESOURCE_PATH / 'assets' / 'death_text.png'
            if text_path.exists():
                self.death_text_img = pygame.image.load(str(text_path)).convert()
                self.death_text_img = pygame.transform.scale(self.death_text_img, (WIDTH, HEIGHT))
        except Exception:
            self.death_text_img = None
        self.overlay_surface = pygame.Surface((WIDTH, HEIGHT))
        self.overlay_surface.fill((0, 0, 0))
        self.overlay_surface.set_alpha(200)

    def create_map(self):
        layouts = {'boundary': import_csv_layout('map/map_FloorBlocks.csv'), 'grass': import_csv_layout('map/map_Grass.csv'), 'object': import_csv_layout('map/map_Objects.csv'), 'entities': import_csv_layout('map/map_Entities.csv')}
        grass_images = import_folder('graphics/grass')
        if not grass_images:
            grass_images = [self._fallback_grass_image()]
        graphics = {'grass': grass_images, 'objects': import_folder('graphics/objects')}
        for style, layout in layouts.items():
            for row_index, row in enumerate(layout):
                for col_index, col in enumerate(row):
                    if col == '-1':
                        continue
                    x = col_index * TILESIZE
                    y = row_index * TILESIZE
                    if style == 'boundary':
                        Tile((x, y), [self.obstacle_sprites], 'invisible')
                    if style == 'grass':
                        random_grass_image = choice(graphics['grass'])
                        Tile((x, y), [self.visible_sprites, self.obstacle_sprites, self.attackable_sprites], 'grass', random_grass_image)
                    if style == 'object':
                        if not graphics['objects']:
                            continue
                        try:
                            surf = graphics['objects'][int(col)]
                        except (ValueError, IndexError):
                            continue
                        Tile((x, y), [self.visible_sprites, self.obstacle_sprites], 'object', surf)
                    if style != 'entities':
                        continue
                    if col == '394':
                        self.player = Player((x, y), [self.visible_sprites], self.obstacle_sprites, self.create_attack, self.destroy_attack, self.create_magic)
                        continue
                    if col == '400':
                        Villager((x, y), [self.visible_sprites, self.obstacle_sprites], '商人', ['欢迎来到我的商店！', '需要什么吗？', '买把好武器去冒险吧！'])
                        continue
                    if col == '390':
                        monster_name = 'bamboo'
                    elif col == '391':
                        monster_name = 'spirit'
                    elif col == '392':
                        monster_name = 'raccoon'
                    else:
                        monster_name = 'squid'
                    Enemy(monster_name, (x, y), [self.visible_sprites, self.attackable_sprites], self.obstacle_sprites, self.damage_player, self.trigger_death_particles, self.add_exp, self.spawn_coins, self.on_enemy_killed, self.spawn_fruits)
                    self.total_enemies += 1
        if not hasattr(self, 'player'):
            self.player = Player((WIDTH // 2, HEIGHT // 2), [self.visible_sprites], self.obstacle_sprites, self.create_attack, self.destroy_attack, self.create_magic)

    def _fallback_grass_image(self):
        '''草地资源缺失时的兜底贴图：保证地图依然可玩，而不是直接崩溃'''

        surf = pygame.Surface((TILESIZE, TILESIZE), pygame.SRCALPHA)
        surf.fill((86, 148, 76))
        for i in range(0, TILESIZE, 16):
            pygame.draw.line(surf, (110, 172, 96), (i, 0), (i + 8, TILESIZE), 2)
        return surf

    def create_attack(self):
        self.current_attack = Weapon(self.player, [self.visible_sprites, self.attack_sprites])

    def create_magic(self, style, strength, cost):
        if style == 'heal':
            self.magic_player.heal(self.player, strength, cost, [self.visible_sprites])
        if style == 'flame':
            self.magic_player.flame(self.player, cost, [self.visible_sprites, self.attack_sprites])

    def destroy_attack(self):
        if self.current_attack:
            self.current_attack.kill()
        self.current_attack = None

    def player_attack_logic(self):
        if self.attack_sprites:
            for attack_sprite in self.attack_sprites:
                try:
                    collision_sprites = pygame.sprite.spritecollide(attack_sprite, self.attackable_sprites, False)
                    if collision_sprites:
                        for target_sprite in collision_sprites:
                            if target_sprite.sprite_type == 'grass':
                                pos = target_sprite.rect.center
                                offset = pygame.math.Vector2(0, 75)
                                for leaf in range(randint(3, 6)):
                                    self.animation_player.create_grass_particles(pos - offset, [self.visible_sprites])
                                target_sprite.kill()
                            else:
                                target_sprite.get_damage(self.player, attack_sprite.sprite_type)
                        continue
                except Exception as e:
                    print(f'Error in attack logic: {e}')

    def damage_player(self, amount, attack_type):
        if self.player.vulnerable:
            self.player.health -= amount
            self.player.vulnerable = False
            self.player.hurt_time = pygame.time.get_ticks()
            self.animation_player.create_particles(attack_type, self.player.rect.center, [self.visible_sprites])

    def trigger_death_particles(self, pos, particle_type):
        self.animation_player.create_particles(particle_type, pos, self.visible_sprites)

    def add_exp(self, amount):
        self.player.exp += amount

    def add_gold(self, amount):
        self.player.gold += amount

    def heal_player(self, amount):
        '''恢复玩家血量，但不超过最大值'''

        try:
            max_health = self.player.stats['health']
            self.player.health = min(max_health, self.player.health + amount)
        except Exception as e:
            print(f'Error healing player: {e}')
            return

    def spawn_fruits(self, pos, heal_amount):
        '''敌人死亡时生成果实，限制数量防止崩溃'''

        try:
            max_fruits_on_map = 50
            if len(self.fruit_sprites) >= max_fruits_on_map:
                self.heal_player(heal_amount)
                return
            fruits_per_pickup = 15
            fruits_to_create = min(3, max(1, heal_amount // fruits_per_pickup))
            remaining = heal_amount
            for _ in range(fruits_to_create):
                if remaining <= 0:
                    break
                offset_x = randint(-30, 30)
                offset_y = randint(-30, 30)
                fruit_value = min(fruits_per_pickup, remaining)
                Fruit((pos[0] + offset_x, pos[1] + offset_y), fruit_value, [self.visible_sprites, self.fruit_sprites])
                remaining -= fruit_value
            if remaining > 0:
                self.heal_player(remaining)
                return
        except Exception as e:
            print(f'Error spawning fruits: {e}')
            return

    def check_fruit_collision(self):
        '''检测玩家与果实碰撞，拾取后恢复血量'''

        try:
            if not self.fruit_sprites:
                return
            fruits_to_remove = []
            for fruit in self.fruit_sprites:
                try:
                    if fruit.hitbox.colliderect(self.player.hitbox):
                        self.heal_player(fruit.heal_amount)
                        fruits_to_remove.append(fruit)
                except Exception:
                    fruits_to_remove.append(fruit)
                    continue
            for fruit in fruits_to_remove:
                fruit.kill()
        except Exception as e:
            print(f'Error in fruit collision: {e}')
            return

    def on_enemy_killed(self):
        '''敌人死亡回调：更新击杀计数并检查通关条件'''

        self.enemies_killed += 1
        if self.total_enemies > 0 and self.enemies_killed >= self.total_enemies:
            self.game_won = True

    def spawn_coins(self, pos, amount):
        try:
            max_coins_on_map = 100
            if len(self.coin_sprites) >= max_coins_on_map:
                self.add_gold(amount)
                return
            coins_per_pickup = 10
            coins_to_create = min(5, max(1, amount // coins_per_pickup))
            remaining = amount
            for _ in range(coins_to_create):
                if remaining <= 0:
                    break
                offset_x = randint(-30, 30)
                offset_y = randint(-30, 30)
                coin_value = min(coins_per_pickup, remaining)
                Coin((pos[0] + offset_x, pos[1] + offset_y), coin_value, [self.visible_sprites, self.coin_sprites])
                remaining -= coin_value
            if remaining > 0:
                self.add_gold(remaining)
                return
        except Exception as e:
            print(f'Error spawning coins: {e}')
            return

    def check_coin_collision(self):
        try:
            if not self.coin_sprites:
                return
            coins_to_remove = []
            for coin in self.coin_sprites:
                try:
                    if coin.hitbox.colliderect(self.player.hitbox):
                        self.add_gold(coin.amount)
                        coins_to_remove.append(coin)
                except Exception:
                    coins_to_remove.append(coin)
                    continue
            for coin in coins_to_remove:
                coin.kill()
        except Exception as e:
            print(f'Error in coin collision: {e}')
            return

    def toggle_menu(self):
        self.game_paused = not self.game_paused

    def check_player_death(self):
        if not self.player.alive and not self.player.death_animation:
            self.player.death_animation = True
            self.player.death_timer = 0

    def run(self):
        if self.game_won:
            self.display_victory()
            pygame.display.update()
            return
        if self.game_over:
            self.display_game_over()
            pygame.display.update()
            return
        if self.player.death_animation:
            self.handle_death_sequence()
            pygame.display.update()
            return
        self.visible_sprites.custom_draw(self.player)
        self.ui.display(self.player)
        self.display_enemy_progress()
        if self.game_paused:
            self.upgrade.display()
        elif self.shop.active:
            self.shop.update()
        else:
            self.visible_sprites.update()
            self.visible_sprites.enemy_update(self.player)
            self.player_attack_logic()
            self.check_player_death()
            self.check_coin_collision()
            self.check_fruit_collision()
        self.minimap.draw()
        if not self.shop.active:
            self.tutorial.update()
            self.tutorial.draw()

    def display_enemy_progress(self):
        '''在屏幕右上角显示敌人击杀进度'''

        if self.total_enemies <= 0:
            return
        try:
            text = f'敌人: {self.enemies_killed} / {self.total_enemies}'
            text_surf = self.font_small.render(text, True, (255, 255, 255))
            text_rect = text_surf.get_rect(topright=(WIDTH - 20, 60))
            bg_rect = text_rect.inflate(10, 6)
            bg_surf = pygame.Surface(bg_rect.size)
            bg_surf.fill((0, 0, 0))
            bg_surf.set_alpha(120)
            self.display_surface.blit(bg_surf, bg_rect)
            self.display_surface.blit(text_surf, text_rect)
        except Exception:
            pass

    def handle_death_sequence(self):
        if not hasattr(self, 'death_sequence_stage'):
            self.death_sequence_stage = 0
            self.death_sequence_timer = 0
        self.death_sequence_timer += pygame.time.get_ticks() - getattr(self, 'death_last_time', pygame.time.get_ticks())
        self.death_last_time = pygame.time.get_ticks()
        stages = [{'duration': 2000, 'effect': 'shake_flash'}, {'duration': 3000, 'effect': 'scene_image'}, {'duration': 3000, 'effect': 'text_image'}]
        total_duration = sum((stage['duration'] for stage in stages))
        if self.death_sequence_timer >= total_duration:
            self.player.death_animation = False
            self.game_over = True
            return
        current_time = 0
        for i, stage in enumerate(stages):
            if current_time <= self.death_sequence_timer < current_time + stage['duration']:
                self.death_sequence_stage = i
                stage_progress = (self.death_sequence_timer - current_time) / stage['duration']
                self.draw_death_stage(stage['effect'], stage_progress)
                break
            current_time += stage['duration']

    def draw_death_stage(self, effect, progress):
        '''使用预加载资源绘制死亡阶段，避免每帧加载图像'''

        if effect == 'shake_flash':
            self.visible_sprites.custom_draw(self.player)
            self.ui.display(self.player)
            shake_intensity = int((1 - progress) * 15)
            flash_alpha = int((1 - progress) * 200)
            if shake_intensity > 0:
                pass
            if flash_alpha > 0:
                if not hasattr(self, '_flash_surface'):
                    self._flash_surface = pygame.Surface((WIDTH, HEIGHT))
                    self._flash_surface.fill((255, 0, 0))
                alpha = flash_alpha * (0.3 + 0.7 * (pygame.time.get_ticks() // 100 % 2))
                self._flash_surface.set_alpha(int(alpha))
                self.display_surface.blit(self._flash_surface, (0, 0))
                return
            return
        if effect == 'scene_image':
            if self.death_scene_img is not None:
                scene_img = self.death_scene_img
                if progress < 0.2:
                    alpha = int(progress / 0.2 * 255)
                    scene_img.set_alpha(alpha)
                    self.display_surface.fill((0, 0, 0))
                    self.display_surface.blit(scene_img, (0, 0))
                    return
                if progress > 0.8:
                    alpha = int((1 - (progress - 0.8) / 0.2) * 255)
                    scene_img.set_alpha(alpha)
                    self.display_surface.fill((0, 0, 0))
                    self.display_surface.blit(scene_img, (0, 0))
                    return
                scene_img.set_alpha(255)
                self.display_surface.blit(scene_img, (0, 0))
                return
            self.display_surface.fill((30, 30, 30))
            text_surf = self.font_small.render('腐蚀正在蔓延...', True, (150, 150, 150))
            text_rect = text_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            self.display_surface.blit(text_surf, text_rect)
            return
        if effect == 'text_image':
            if self.death_text_img is not None:
                text_img = self.death_text_img
                if progress < 0.2:
                    alpha = int(progress / 0.2 * 255)
                    text_img.set_alpha(alpha)
                    self.display_surface.fill((0, 0, 0))
                    self.display_surface.blit(text_img, (0, 0))
                    return
                if progress > 0.8:
                    alpha = int((1 - (progress - 0.8) / 0.2) * 255)
                    text_img.set_alpha(alpha)
                    self.display_surface.fill((0, 0, 0))
                    self.display_surface.blit(text_img, (0, 0))
                    return
                text_img.set_alpha(255)
                self.display_surface.blit(text_img, (0, 0))
                return
            self.display_surface.fill((0, 0, 0))
            lines = ['微光熄灭，绿野枯萎，', '艾瑟尔的故事，到此为止。']
            for i, line in enumerate(lines):
                text_surf = self.font_medium.render(line, True, (200, 200, 200))
                text_rect = text_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30 + i * 40))
                self.display_surface.blit(text_surf, text_rect)

    def display_game_over(self):
        '''使用预加载的覆盖层和字体显示游戏结束画面'''

        self.display_surface.blit(self.overlay_surface, (0, 0))
        title_surf = self.font_large.render('游戏结束', True, (255, 0, 0))
        title_rect = title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 3))
        self.display_surface.blit(title_surf, title_rect)
        text_surf = self.font_small.render('按 Enter 重新开始    按 Esc 返回标题', True, (200, 200, 200))
        text_rect = text_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.display_surface.blit(text_surf, text_rect)

    def display_victory(self):
        '''显示胜利画面：击败所有敌人后触发'''

        self.display_surface.blit(self.overlay_surface, (0, 0))
        title_surf = self.font_large.render('恭喜通关！', True, (255, 215, 0))
        title_rect = title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 3))
        self.display_surface.blit(title_surf, title_rect)
        subtitle_surf = self.font_medium.render('你击败了所有敌人，拯救了海拉鲁！', True, (255, 255, 255))
        subtitle_rect = subtitle_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 20))
        self.display_surface.blit(subtitle_surf, subtitle_rect)
        if hasattr(self.player, 'gold'):
            stats_text = f'获得金币: {self.player.gold}  获得经验: {self.player.exp}'
            stats_surf = self.font_small.render(stats_text, True, (200, 200, 200))
            stats_rect = stats_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 40))
            self.display_surface.blit(stats_surf, stats_rect)
        hint_surf = self.font_small.render('按 Enter 重新开始    按 Esc 返回标题', True, (200, 200, 200))
        hint_rect = hint_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 100))
        self.display_surface.blit(hint_surf, hint_rect)


class YSortCameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.half_width = self.display_surface.get_size()[0] // 2
        self.half_height = self.display_surface.get_size()[1] // 2
        self.offset = pygame.math.Vector2()
        self.floor_surf = pygame.image.load(RESOURCE_PATH / 'graphics/tilemap/ground.png').convert()
        self.floor_rect = self.floor_surf.get_rect(topleft=(0, 0))

    def custom_draw(self, player):
        self.offset.x = player.rect.centerx - self.half_width
        self.offset.y = player.rect.centery - self.half_height
        floor_offset_pos = self.floor_rect.topleft - self.offset
        self.display_surface.blit(self.floor_surf, floor_offset_pos)
        for sprite in sorted(self.sprites(), key=(lambda sprite: sprite.rect.centery)):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)

    def enemy_update(self, player):
        enemy_sprites = [sprite for sprite in self.sprites() if hasattr(sprite, 'sprite_type') if sprite.sprite_type == 'enemy']
        for enemy in enemy_sprites:
            enemy.enemy_update(player)


