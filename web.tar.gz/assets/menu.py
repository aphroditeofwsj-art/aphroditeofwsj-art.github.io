import pygame
from settings import *
from support import get_font

class Menu:
    def __init__(self, game):
        self.game = game
        self.display_surface = pygame.display.get_surface()
        self.font = get_font(UI_FONT_SIZE + 8)
        self.font_large = get_font(UI_FONT_SIZE + 20)
        self.font_small = get_font(UI_FONT_SIZE)
        self.state = 'menu'
        self.selected_index = 0
        self.menu_items = ['开始游戏', '操作说明', '退出']
        self.bg_color = (10, 10, 30)
        self.selected_color = UI_BORDER_COLOR_ACTIVE
        self.normal_color = TEXT_COLOR
        self.title_color = (255, 215, 0)
        self.help_lines = [
            'W A S D        移动',
            '鼠标左键      攻击',
            'Q / E          切换武器 / 魔法',
            'M              打开升级面板',
            'G              打开商店',
            '空格           推进剧情',
            'Esc            关闭面板 / 返回',
        ]

    def item_rect(self, index):
        return pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + index * 60 - 15, 200, 40)

    def draw(self):
        if self.state == 'help':
            self.draw_help()
            return
        if self.state == 'bye':
            self.draw_bye()
            return
        self.display_surface.fill(self.bg_color)
        title_surf = self.font_large.render('海拉鲁失落王国', True, self.title_color)
        title_rect = title_surf.get_rect(midtop=(WIDTH // 2, HEIGHT // 4))
        self.display_surface.blit(title_surf, title_rect)
        y_offset = HEIGHT // 2
        for index, item in enumerate(self.menu_items):
            x = WIDTH // 2
            y = y_offset + index * 60
            if index == self.selected_index:
                color = self.selected_color
                pygame.draw.rect(self.display_surface, UI_BG_COLOR, self.item_rect(index))
                pygame.draw.rect(self.display_surface, self.selected_color, self.item_rect(index), 3)
            else:
                color = self.normal_color
            item_surf = self.font.render(item, True, color)
            item_rect = item_surf.get_rect(center=(x, y))
            self.display_surface.blit(item_surf, item_rect)
            continue
        pygame.display.update()

    def draw_help(self):
        self.display_surface.fill(self.bg_color)
        title_surf = self.font_large.render('操作说明', True, self.title_color)
        self.display_surface.blit(title_surf, title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 4)))
        y = HEIGHT // 2 - 90
        for line in self.help_lines:
            surf = self.font_small.render(line, True, self.normal_color)
            self.display_surface.blit(surf, surf.get_rect(center=(WIDTH // 2, y)))
            y += 34
        hint = self.font_small.render('按 Enter / Esc 返回', True, (130, 130, 140))
        self.display_surface.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 90)))
        pygame.display.update()

    def draw_bye(self):
        self.display_surface.fill(self.bg_color)
        title_surf = self.font_large.render('感谢游玩', True, self.title_color)
        self.display_surface.blit(title_surf, title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 40)))
        body = self.font_small.render('直接关掉浏览器标签页即可', True, self.normal_color)
        self.display_surface.blit(body, body.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 20)))
        hint = self.font_small.render('按 Enter 返回标题', True, (130, 130, 140))
        self.display_surface.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 70)))
        pygame.display.update()

    def handle_event(self, event):
        if self.state in ('help', 'bye'):
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_SPACE):
                self.state = 'menu'
            return
        if event.type == pygame.MOUSEMOTION:
            for index in range(len(self.menu_items)):
                if self.item_rect(index).collidepoint(event.pos):
                    self.selected_index = index
                    break
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for index in range(len(self.menu_items)):
                if self.item_rect(index).collidepoint(event.pos):
                    self.selected_index = index
                    self.select_item()
                    return
        if event.type == pygame.KEYDOWN:
            key_name = pygame.key.name(event.key).lower()
            if key_name == 'up':
                if self.selected_index > 0:
                    self.selected_index -= 1
                return
            if key_name == 'down':
                if self.selected_index < len(self.menu_items) - 1:
                    self.selected_index += 1
                return
            if event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                self.select_item()
                return
            if key_name == 'escape':
                self.state = 'bye'

    def select_item(self):
        if self.selected_index == 0:
            self.game.start_game()
            return
        if self.selected_index == 1:
            self.state = 'help'
            return
        if self.selected_index == 2:
            self.state = 'bye'

    def run(self):
        self.draw()
