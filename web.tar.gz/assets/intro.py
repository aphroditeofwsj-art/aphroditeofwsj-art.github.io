import pygame
import math
import re
from settings import *
from support import RESOURCE_PATH, get_font

class Intro:
    def __init__(self, game):
        self.game = game
        self.display_surface = pygame.display.get_surface()
        self.font = get_font(UI_FONT_SIZE)
        self.font_large = get_font(UI_FONT_SIZE + 12)
        self.font_title = get_font(UI_FONT_SIZE + 28)
        self.state = 'fade_in'
        self.current_text_index = 0
        self.text_timer = 0
        self.text_duration = 100000
        self.fade_timer = 0
        self.fade_duration = 260
        self.images = {'sword': pygame.image.load(RESOURCE_PATH / 'graphics/weapons/sword/full.png').convert_alpha(), 'ground': pygame.image.load(RESOURCE_PATH / 'graphics/tilemap/ground.png').convert_alpha(), 'squid': pygame.image.load(RESOURCE_PATH / 'graphics/monsters/squid/idle/0.png').convert_alpha(), 'raccoon': pygame.image.load(RESOURCE_PATH / 'graphics/monsters/raccoon/idle/0.png').convert_alpha(), 'spirit': pygame.image.load(RESOURCE_PATH / 'graphics/monsters/spirit/idle/0.png').convert_alpha(), 'bamboo': pygame.image.load(RESOURCE_PATH / 'graphics/monsters/bamboo/idle/0.png').convert_alpha(), 'player': pygame.image.load(RESOURCE_PATH / 'graphics/test/player.png').convert_alpha(), 'object': pygame.image.load(RESOURCE_PATH / 'graphics/objects/0.png').convert_alpha(), 'axe': pygame.image.load(RESOURCE_PATH / 'graphics/weapons/axe/full.png').convert_alpha(), 'lance': pygame.image.load(RESOURCE_PATH / 'graphics/weapons/lance/full.png').convert_alpha(), 'rapier': pygame.image.load(RESOURCE_PATH / 'graphics/weapons/rapier/full.png').convert_alpha(), 'sai': pygame.image.load(RESOURCE_PATH / 'graphics/weapons/sai/full.png').convert_alpha(), 'flame': pygame.image.load(RESOURCE_PATH / 'graphics/particles/flame/fire.png').convert_alpha(), 'heal': pygame.image.load(RESOURCE_PATH / 'graphics/particles/heal/heal.png').convert_alpha(), 'grass': pygame.image.load(RESOURCE_PATH / 'graphics/grass/grass_1.png').convert_alpha(), 'floor': pygame.image.load(RESOURCE_PATH / 'graphics/tilemap/Floor.png').convert_alpha(), 'nova': pygame.image.load(RESOURCE_PATH / 'graphics/particles/nova/0.png').convert_alpha(), 'sparkle': pygame.image.load(RESOURCE_PATH / 'graphics/particles/sparkle/0.png').convert_alpha(), 'smoke': pygame.image.load(RESOURCE_PATH / 'graphics/particles/smoke/0.png').convert_alpha(), 'thunder': pygame.image.load(RESOURCE_PATH / 'graphics/particles/thunder/0.png').convert_alpha()}
        try:
            self.images['scene1'] = pygame.image.load(RESOURCE_PATH / 'assets/scene1.png').convert_alpha()
            self.images['scene2'] = pygame.image.load(RESOURCE_PATH / 'assets/scene2.png').convert_alpha()
            self.images['scene3'] = pygame.image.load(RESOURCE_PATH / 'assets/scene3.png').convert_alpha()
            self.images['scene4'] = pygame.image.load(RESOURCE_PATH / 'assets/scene4.png').convert_alpha()
            self.images['scene5'] = pygame.image.load(RESOURCE_PATH / 'assets/scene5.png').convert_alpha()
        except:
            pass
        self.story_texts = [{'title': '海拉鲁失落王国', 'subtitle': 'The Lost Kingdom of Hyrule', 'text': '', 'image': 'sword', 'effect': 'glow', 'bg': 'dark'}, {'title': '第一章：繁荣与黑暗', 'subtitle': '', 'text': '数千年前，海拉鲁王国曾是繁荣昌盛的魔法王国。人民与自然和谐共存，三角神力守护着这片土地。', 'image': 'ground', 'effect': 'pan', 'bg': 'light'}, {'title': '', 'subtitle': '', 'text': '然而，贪婪的魔族觊觎神力，在黑暗中蠢蠢欲动...', 'image': 'sparkle', 'effect': 'float', 'bg': 'dark'}, {'title': '第二章：灾难降临', 'subtitle': '', 'text': '一天，黑暗君主 加农多夫 打破了封印，率领魔兽大军入侵海拉鲁。', 'image': 'scene2' if 'scene2' in self.images else 'spirit', 'effect': 'scene', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '王国在短时间内被黑暗吞噬，城堡沦陷，光明逐渐消退。', 'image': 'thunder', 'effect': 'flash', 'bg': 'dark'}, {'title': '第三章：英雄的牺牲', 'subtitle': '', 'text': '最终，英雄们用尽全力将加农多夫封印，但这代价是惨重的——王国四分五裂，化为废墟。', 'image': 'axe', 'effect': 'darken', 'bg': 'dark'}, {'title': '第四章：魔兽横行', 'subtitle': '', 'text': '🦑 乌贼 - 速度快的小型怪物，善于快速攻击并躲避', 'image': 'scene4' if 'scene4' in self.images else 'squid', 'effect': 'scene', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '🦝 浣熊 - 凶猛的近战野兽，拥有强大的爪击能力', 'image': 'scene3' if 'scene3' in self.images else 'raccoon', 'effect': 'scene', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '👻 幽灵 - 使用闪电攻击的灵体敌人，难以捉摸', 'image': 'spirit', 'effect': 'ghost', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '🎋 竹妖 - 敏捷的植物系敌人，擅长远程叶刃攻击', 'image': 'bamboo', 'effect': 'float', 'bg': 'dark'}, {'title': '第五章：武器系统', 'subtitle': '', 'text': '⚔️ 剑 - 平衡的攻击速度和伤害，适合新手使用', 'image': 'sword', 'effect': 'weapon', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '⛏️ 斧 - 高伤害但攻速较慢，适合对付高血量敌人', 'image': 'axe', 'effect': 'weapon', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '🗡️ 长矛 - 攻击范围最远，适合保持距离战斗', 'image': 'lance', 'effect': 'weapon', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '🔪 细剑 - 快速攻击但伤害较低，适合连击', 'image': 'rapier', 'effect': 'weapon', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '🥷 双刺 - 平衡的快速武器，攻守兼备', 'image': 'sai', 'effect': 'weapon', 'bg': 'dark'}, {'title': '第六章：魔法系统', 'subtitle': '', 'text': '🔥 火焰魔法 - 强大的攻击魔法，可造成范围伤害', 'image': 'flame', 'effect': 'fire', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '💚 治愈魔法 - 恢复生命值，在战斗中至关重要', 'image': 'heal', 'effect': 'heal', 'bg': 'dark'}, {'title': '第七章：世界探索', 'subtitle': '', 'text': '探索广阔的海拉鲁大陆，发现隐藏的宝藏和秘密', 'image': 'scene5' if 'scene5' in self.images else 'grass', 'effect': 'scene', 'bg': 'light'}, {'title': '', 'subtitle': '', 'text': '收集散落各地的神器，解锁强大的能力', 'image': 'nova', 'effect': 'glow', 'bg': 'dark'}, {'title': '第八章：你的使命', 'subtitle': '', 'text': '你醒来时发现自己失去了所有记忆，但手中紧握着一把生锈的上古之剑。', 'image': 'scene1' if 'scene1' in self.images else 'player', 'effect': 'scene', 'bg': 'dark'}, {'title': '', 'subtitle': '', 'text': '一位神秘的老者告诉你：只有集齐散落各地的神器，击败四方守护的魔兽，才能重新封印加农多夫，拯救海拉鲁。', 'image': 'object', 'effect': 'float', 'bg': 'dark'}, {'title': '准备好开始冒险了吗？', 'subtitle': '', 'text': '', 'image': None, 'effect': 'glow', 'bg': 'dark'}]
        self.bg_color_dark = (5, 5, 20)
        self.bg_color_light = (20, 30, 50)
        self._strip_unsupported_glyphs()

    def _strip_unsupported_glyphs(self):
        '''字体里没有 emoji 字形，留着会显示成方框，这里统一去掉。'''

        emoji = re.compile(r'[\U0001F000-\U0001FAFF\u2190-\u21FF\u2600-\u27BF\u2B00-\u2BFF\uFE0F]+\s*')
        for story in self.story_texts:
            for key in ('title', 'subtitle', 'text'):
                value = story.get(key)
                if value:
                    story[key] = emoji.sub('', value).strip()
        self.text_color = TEXT_COLOR
        self.title_color = (255, 215, 0)
        self.subtitle_color = (150, 150, 200)
        self.alpha = 0
        self.target_alpha = 255

    def draw(self):
        current_story = self.story_texts[self.current_text_index]
        bg_color = self.bg_color_light if current_story.get('bg') == 'light' else self.bg_color_dark
        self.display_surface.fill(bg_color)
        image_bottom = None
        if current_story['image']:
            image = self.images[current_story['image']]
            if current_story['effect'] == 'scene':
                img_width, img_height = image.get_size()
                scale_factor = min(WIDTH * 0.75 / img_width, HEIGHT * 0.5 / img_height)
                new_width = int(img_width * scale_factor)
                new_height = int(img_height * scale_factor)
                image = pygame.transform.scale(image, (new_width, new_height))
                float_y = math.sin(pygame.time.get_ticks() / 1000) * 5
                image_rect = image.get_rect(center=(WIDTH // 2, HEIGHT * 0.30 + float_y))
                image_bottom = image_rect.bottom + 10
                image.set_alpha(self.alpha)
                border_surface = pygame.Surface((new_width + 20, new_height + 20), pygame.SRCALPHA)
                glow_alpha = int(30 + 20 * math.sin(pygame.time.get_ticks() / 600))
                pygame.draw.rect(border_surface, (255, 215, 0, glow_alpha), border_surface.get_rect(), border_radius=5)
                border_rect = border_surface.get_rect(center=image_rect.center)
                self.display_surface.blit(border_surface, border_rect)
                self.display_surface.blit(image, image_rect)
            else:
                image = pygame.transform.scale(image, (180, 180))
                if current_story['effect'] == 'shake' and self.state == 'show':
                    shake_x = math.sin(pygame.time.get_ticks() / 30) * 5
                    shake_y = math.cos(pygame.time.get_ticks() / 35) * 5
                    image_rect = image.get_rect(midtop=(WIDTH // 2 + shake_x, HEIGHT // 6 + shake_y))
                elif current_story['effect'] in ('float', 'ghost') and self.state == 'show':
                    float_y = math.sin(pygame.time.get_ticks() / 500) * 10
                    float_x = math.cos(pygame.time.get_ticks() / 700) * 5
                    image_rect = image.get_rect(midtop=(WIDTH // 2 + float_x, HEIGHT // 6 + float_y))
                else:
                    image_rect = image.get_rect(midtop=(WIDTH // 2, HEIGHT // 6))
                if current_story['effect'] == 'ghost':
                    image_alpha = int(150 + 100 * math.sin(pygame.time.get_ticks() / 300))
                    image.set_alpha(image_alpha)
                else:
                    image.set_alpha(self.alpha)
                self.display_surface.blit(image, image_rect)
                if current_story['effect'] in ('glow', 'fire'):
                    glow_surface = pygame.Surface((250, 250), pygame.SRCALPHA)
                    glow_radius = 50 + math.sin(pygame.time.get_ticks() / 500) * 10
                    color = (255, 215, 0) if current_story['effect'] == 'glow' else (255, 100, 0)
                    pygame.draw.circle(glow_surface, (*color, int(40 * (self.alpha / 255))), (125, 125), int(glow_radius))
                    pygame.draw.circle(glow_surface, (*color, int(20 * (self.alpha / 255))), (125, 125), int(glow_radius * 1.5))
                    glow_rect = glow_surface.get_rect(center=(WIDTH // 2, HEIGHT // 6 + 90))
                    self.display_surface.blit(glow_surface, glow_rect)
        if current_story['effect'] == 'darken' and self.state == 'show':
            darken_alpha = 80 + math.sin(pygame.time.get_ticks() / 800) * 40
            darken_overlay = pygame.Surface((WIDTH, HEIGHT))
            darken_overlay.fill((0, 0, 0))
            darken_overlay.set_alpha(darken_alpha)
            self.display_surface.blit(darken_overlay, (0, 0))
        cursor_y = HEIGHT // 2 - 40
        if image_bottom is not None:
            # 有大插图时把文字压到图片下方，避免盖在插画上
            cursor_y = max(cursor_y, image_bottom + 14)
        if current_story['title']:
            title_surf = self.font_title.render(current_story['title'], True, self.title_color)
            title_rect = title_surf.get_rect(midtop=(WIDTH // 2, cursor_y))
            if current_story['effect'] == 'flash' and self.state == 'show':
                title_alpha = self.alpha if pygame.time.get_ticks() % 150 > 75 else int(self.alpha * 0.3)
                title_surf.set_alpha(title_alpha)
            else:
                title_surf.set_alpha(self.alpha)
            self.display_surface.blit(title_surf, title_rect)
            cursor_y = title_rect.bottom + 8
        if current_story['subtitle']:
            subtitle_surf = self.font.render(current_story['subtitle'], True, self.subtitle_color)
            subtitle_rect = subtitle_surf.get_rect(midtop=(WIDTH // 2, cursor_y))
            subtitle_surf.set_alpha(self.alpha)
            self.display_surface.blit(subtitle_surf, subtitle_rect)
            cursor_y = subtitle_rect.bottom + 8
        if current_story['text']:
            lines = self.wrap_text(current_story['text'], WIDTH - 200)
            y_offset = cursor_y + 12
            for i, line in enumerate(lines):
                text_surf = self.font.render(line, True, self.text_color)
                text_rect = text_surf.get_rect(midtop=(WIDTH // 2, y_offset + i * 30))
                text_surf.set_alpha(self.alpha)
                self.display_surface.blit(text_surf, text_rect)
        if self.state in ('fade_in', 'fade_out'):
            # 过场黑幕：alpha 255 = 全亮，0 = 全黑；黑幕始终按 255-alpha 叠加，
            # 这样淡出是一点点压黑、淡入是一点点揭开，不会出现"先黑再亮回来"的重影
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.fill((0, 0, 0))
            overlay.set_alpha(max(0, min(255, 255 - self.alpha)))
            self.display_surface.blit(overlay, (0, 0))
        if self.state == 'show':
            press_text = self.font.render('按 空格键 继续    按 R 跳过剧情', True, (120, 120, 120))
            press_rect = press_text.get_rect(midbottom=(WIDTH // 2, HEIGHT - 50))
            press_surf = pygame.Surface(press_text.get_size())
            press_surf.fill(bg_color)
            press_surf.blit(press_text, (0, 0))
            flash_alpha = int(150 + 100 * math.sin(pygame.time.get_ticks() / 200))
            press_surf.set_alpha(flash_alpha)
            self.display_surface.blit(press_surf, press_rect)
        pygame.display.update()

    def wrap_text(self, text, max_width):
        lines = []
        words = text.split()
        current_line = ''
        for word in words:
            test_line = current_line + word + ' '
            test_surf = self.font.render(test_line, True, self.text_color)
            if test_surf.get_width() <= max_width:
                current_line = test_line
            else:
                lines.append(current_line.strip())
                current_line = word + ' '
        if current_line:
            lines.append(current_line.strip())
        return lines

    def update(self, dt):
        dt = min(dt, 100)
        if self.state == 'fade_in':
            self.fade_timer += dt
            self.alpha = int(self.fade_timer / self.fade_duration * 255)
            if self.alpha >= 255:
                self.alpha = 255
                self.state = 'show'
                self.text_timer = 0
                return
            return
        if self.state == 'show':
            self.text_timer += dt
            if self.text_timer >= self.text_duration:
                self.state = 'fade_out'
                self.fade_timer = 0
                return
            return
        if self.state == 'fade_out':
            self.fade_timer += dt
            self.alpha = 255 - int(self.fade_timer / self.fade_duration * 255)
            if self.alpha <= 0:
                self.alpha = 0
                self.next_text()

    def handle_event(self, event):
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
            # 手机上没有空格键，点一下画面就当作「继续」
            self.press_continue()
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                self.game.start_menu()
                return
            if event.key == pygame.K_SPACE:
                self.press_continue()
                return
            if event.key == pygame.K_RETURN:
                self.game.start_menu()

    def press_continue(self):
        '''空格 / 点击 / 触摸都走这里：推进一步过场'''

        if self.state == 'show':
            self.state = 'fade_out'
            self.fade_timer = 0
            self.alpha = 255
        elif self.state == 'fade_out':
            # 淡出途中再按一次：直接结束本页，立刻进入下一页，连按不会发闷
            self.alpha = 0
            self.next_text()
        elif self.state == 'fade_in':
            # 淡入过程中按空格直接完成淡入，连续按键不会卡顿
            self.alpha = 255
            self.fade_timer = self.fade_duration
            self.state = 'show'
            self.text_timer = 0

    def next_text(self):
        self.current_text_index += 1
        if self.current_text_index >= len(self.story_texts):
            self.game.start_menu()
            return
        self.state = 'fade_in'
        self.fade_timer = 0
        self.alpha = 0
        self.text_timer = 0


