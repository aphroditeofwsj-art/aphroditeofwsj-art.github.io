"""游戏入口。

- 桌面运行：python code/main.py
- 浏览器运行：由 pygbag 打包，入口同样是本文件
"""
import sys
from pathlib import Path

# Windows 控制台 / 浏览器终端统一用 UTF-8，避免中文 print 直接抛异常
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, 'reconfigure'):
        try:
            _stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

import traceback
import pygame
import os
import asyncio


def _write_crash_log(text):
    '''打包成 exe 后没有控制台，把崩溃写到用户目录，方便排查。'''

    try:
        log_dir = Path.home() / 'LostKingdom_logs'
        log_dir.mkdir(exist_ok=True)
        with open(log_dir / 'crash.log', 'a', encoding='utf-8') as f:
            f.write(text + '\n')
    except Exception:
        pass


if getattr(sys, 'frozen', False):
    def _excepthook(exc_type, exc_value, exc_tb):
        text = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
        _write_crash_log(text)
        sys.__excepthook__(exc_type, exc_value, exc_tb)
    sys.excepthook = _excepthook


def get_base_path():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS)
    if sys.platform == 'emscripten':
        return Path(__file__).resolve().parent
    return Path(__file__).resolve().parent.parent


PROJECT_ROOT = get_base_path()
try:
    os.chdir(PROJECT_ROOT)
except OSError:
    pass

from settings import *          # noqa: E402,F401,F403
from support import get_font    # noqa: E402
import touch                    # noqa: E402
from level import Level         # noqa: E402
from menu import Menu           # noqa: E402
from intro import Intro         # noqa: E402


def create_knight_icon():
    '''创建像素骑士图标（16x16像素）'''

    icon = pygame.Surface((16, 16), pygame.SRCALPHA)
    icon.fill((0, 0, 0, 0))
    knight_pixels = [[(139, 69, 19), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None, (139, 69, 19), None, (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None, None, None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (128, 0, 0), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (128, 0, 0), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), None, (200, 200, 200), (160, 82, 45), (160, 82, 45), (160, 82, 45), None, None, (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(139, 69, 19), None, None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (139, 69, 19), None, None, (139, 69, 19), (139, 69, 19), None, None], [(139, 69, 19), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), (128, 0, 0), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45)], [(139, 69, 19), (65, 105, 225), None, None, None, None, (128, 0, 0), (128, 0, 0), (128, 0, 0), None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45)], [(139, 69, 19), (65, 105, 225), None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), (65, 105, 225), None, None, None, (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), (65, 105, 225), None, None, None, (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), None, None, None, None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), None, None, (160, 82, 45), (160, 82, 45), None, None], [(139, 69, 19), None, None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), None], [None, None, None, None, None, (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), (128, 0, 0), (160, 82, 45), (160, 82, 45), None, None, None, None], [None, None, None, None, (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), (128, 0, 0), (128, 0, 0), (160, 82, 45), (160, 82, 45), None, None, None, None]]
    for y, row in enumerate(knight_pixels):
        for x, color in enumerate(row):
            if color is not None:
                icon.set_at((x, y), color)
    return icon


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Lost Kingdom of Hyrule')
        pygame.display.set_icon(create_knight_icon())
        self.clock = pygame.time.Clock()
        self._init_audio()
        self.game_state = 'intro'
        self.intro = Intro(self)
        self.menu = Menu(self)
        self.level = None
        self.error_text = ''
        self.error_shown = False
        self.font_error_title = get_font(42)
        self.font_error_body = get_font(22)
        self.font_error_small = get_font(18)

    def _init_audio(self):
        '''背景音乐失败也不能阻止游戏启动（浏览器里音频常被策略拦截）'''

        try:
            main_sound = pygame.mixer.Sound(str(PROJECT_ROOT / 'audio' / 'main.ogg'))
            main_sound.set_volume(0.5)
            main_sound.play(loops=-1)
        except Exception as e:
            print(f'Audio disabled: {e}', flush=True)

    def start_menu(self):
        self.game_state = 'menu'
        self.level = None

    def start_game(self):
        try:
            self.level = Level()
            self.game_state = 'playing'
        except Exception as e:
            traceback.print_exc()
            self.level = None
            self.fail(e)

    def fail(self, exc):
        '''把异常变成屏幕上可见的提示，而不是让整个页面黑掉 / 灰掉'''

        self.error_text = f'{type(exc).__name__}: {exc}'
        self.game_state = 'error'
        self.level = None
        if not self.error_shown:
            self.error_shown = True
            print(f'[ERROR] {self.error_text}', flush=True)

    def recover(self):
        self.error_shown = False
        self.error_text = ''

    def draw_error(self):
        self.screen.fill((14, 16, 26))
        title = self.font_error_title.render('游戏遇到问题', True, (255, 120, 120))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 3)))
        y = HEIGHT // 2 - 20
        for line in self._wrap_error(self.error_text, WIDTH - 200)[:4]:
            surf = self.font_error_body.render(line, True, (200, 200, 210))
            self.screen.blit(surf, surf.get_rect(center=(WIDTH // 2, y)))
            y += 32
        hint = self.font_error_small.render('按 Enter 返回标题    按 R 重新开始', True, (150, 150, 160))
        self.screen.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 90)))
        pygame.display.update()

    def _wrap_error(self, text, max_width):
        lines = []
        current = ''
        for ch in text:
            test = current + ch
            if current and self.font_error_body.size(test)[0] > max_width:
                lines.append(current)
                current = ch
            else:
                current = test
        if current:
            lines.append(current)
        return lines

    def handle_event(self, event):
        touch.note_event(event)
        if self.game_state == 'intro':
            self.intro.handle_event(event)
            return
        if self.game_state == 'menu':
            self.menu.handle_event(event)
            return
        if self.game_state == 'error':
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                    self.recover()
                    self.start_menu()
                elif event.key == pygame.K_r:
                    self.recover()
                    self.start_game()
            return
        level = self.level
        if level is None:
            self.start_menu()
            return
        if level.touch.handle_event(event):
            return
        if event.type == pygame.KEYDOWN:
            key_name = pygame.key.name(event.key).lower()
            if key_name == 't':
                touch.toggle_forced()
                return
            if event.key == pygame.K_RETURN:
                if level.game_over or level.game_won:
                    self.start_game()
                return
            if event.key == pygame.K_ESCAPE and (level.game_over or level.game_won):
                self.start_menu()
                return
            if key_name == 'm' and not level.tutorial.active and not level.shop.active:
                level.toggle_menu()
            if key_name == 'g':
                if not level.shop.active:
                    class TempVillager:
                        name = '商店'
                        has_shop = True

                    level.shop.open(TempVillager())
                elif not level.tutorial.active:
                    level.shop.close()
            if key_name == 'q':
                level.player.switch_weapon_event()
            if key_name == 'e':
                level.player.switch_magic_event()
            if level.shop.active:
                level.shop.handle_event(event)
            if level.tutorial.active:
                level.tutorial.handle_event(event)
                return
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if level.tutorial.active:
                level.tutorial.handle_event(event)
            elif event.button == 1 and not (level.shop.active or level.game_paused or level.game_over or level.game_won):
                # 鼠标左键攻击：走事件而不是只靠轮询，极短的一下点按也不会漏
                level.player.trigger_attack()

    def update(self, dt):
        if self.game_state == 'intro':
            self.intro.update(dt)

    def draw(self):
        if self.game_state == 'intro':
            self.intro.draw()
        elif self.game_state == 'menu':
            self.menu.run()
        elif self.game_state == 'error':
            self.draw_error()
        elif self.level is not None:
            self.screen.fill(WATER_COLOR)
            self.level.run()
            pygame.display.update()

    async def run(self):
        running = True
        last_time = pygame.time.get_ticks()
        while running:
            try:
                current_time = pygame.time.get_ticks()
                dt = current_time - last_time
                last_time = current_time
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        break
                    self.handle_event(event)
                if not running:
                    break
                self.update(dt)
                self.draw()
                self.clock.tick(FPS)
            except Exception as e:
                # 关键：浏览器里不能因为一帧异常就退出主循环，否则整页会变成灰屏
                traceback.print_exc()
                self.fail(e)
            # pygbag 需要把控制权交还给浏览器，否则页面会假死
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    game = Game()
    await game.run()


if __name__ == '__main__':
    asyncio.run(main())
