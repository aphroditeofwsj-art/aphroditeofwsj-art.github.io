import pygame
import sys
import os
import asyncio
from pathlib import Path

def get_base_path():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS)
    if sys.platform == 'emscripten':
        return Path(__file__).resolve().parent
    return Path(__file__).resolve().parent.parent

PROJECT_ROOT = get_base_path()
try:
    os.chdir(PROJECT_ROOT)
except OSError:
    pass
from settings import *
from level import Level
from menu import Menu
from intro import Intro

def create_knight_icon():
    '''创建像素骑士图标（16x16像素）'''

    icon = pygame.Surface((16, 16), pygame.SRCALPHA)
    icon.fill((0, 0, 0, 0))
    knight_pixels = [[(139, 69, 19), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None, (139, 69, 19), None, (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None, None, None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (128, 0, 0), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (128, 0, 0), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(200, 200, 200), (200, 200, 200), (200, 200, 200), (200, 200, 200), None, (200, 200, 200), (160, 82, 45), (160, 82, 45), (160, 82, 45), None, None, (139, 69, 19), (139, 69, 19), (139, 69, 19), None, None], [(139, 69, 19), None, None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (139, 69, 19), None, None, (139, 69, 19), (139, 69, 19), None, None], [(139, 69, 19), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), (128, 0, 0), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45)], [(139, 69, 19), (65, 105, 225), None, None, None, None, (128, 0, 0), (128, 0, 0), (128, 0, 0), None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45)], [(139, 69, 19), (65, 105, 225), None, None, None, (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (160, 82, 45), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), (65, 105, 225), None, None, None, (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [(139, 69, 19), (65, 105, 225), None, None, None, (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [None, (65, 105, 225), None, None, None, (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [None, None, None, (160, 82, 45), (160, 82, 45), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (65, 105, 225), (128, 0, 0), (128, 0, 0), None, None], [None, None, None, (160, 82, 45), (160, 82, 45), None, None, None, None, None, None, None, None, None, None, None], [None, None, None, (160, 82, 45), (160, 82, 45), None, None, None, None, None, None, None, None, None, None, None], [None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None], [None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]]
    for y, row in enumerate(knight_pixels):
        for x, color in enumerate(row):
            if color is not None:
                icon.set_at((x, y), color)
    return icon

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Lost Kingdom of Hyrule')
        icon = create_knight_icon()
        pygame.display.set_icon(icon)
        self.clock = pygame.time.Clock()
        try:
            main_sound = pygame.mixer.Sound(PROJECT_ROOT / 'audio' / 'main.ogg')
            main_sound.set_volume(0.5)
            main_sound.play(loops=-1)
        except Exception as e:
            print(f'Audio disabled: {e}')
        self.game_state = 'intro'
        self.intro = Intro(self)
        self.menu = Menu(self)
        self.level = None

    def start_menu(self):
        self.game_state = 'menu'

    def start_game(self):
        self.game_state = 'playing'
        self.level = Level()
        print('[OK] Level initialized')

    async def run(self):
        print('Starting game...')
        last_time = pygame.time.get_ticks()
        running = True
        while running:
            try:
                current_time = pygame.time.get_ticks()
                dt = current_time - last_time
                last_time = current_time
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        break
                    if self.game_state == 'intro':
                        self.intro.handle_event(event)
                        continue
                    if self.game_state == 'menu':
                        self.menu.handle_event(event)
                        continue
                    if event.type == pygame.KEYDOWN:
                        key_name = pygame.key.name(event.key).lower()
                        if event.key == pygame.K_RETURN:
                            if self.level.game_over or self.level.game_won:
                                self.start_game()
                            continue
                        if event.key == pygame.K_SPACE:
                            print('Space key pressed')
                        if key_name == 'm' and not self.level.tutorial.active and not self.level.shop.active:
                            self.level.toggle_menu()
                        if key_name == 'g':
                            if not self.level.shop.active:
                                class TempVillager:
                                    name = '商店'
                                    has_shop = True

                                self.level.shop.open(TempVillager())
                            elif not self.level.tutorial.active:
                                self.level.shop.close()
                        if key_name == 'q':
                            self.level.player.switch_weapon_event()
                        if key_name == 'e':
                            self.level.player.switch_magic_event()
                        if self.level.shop.active:
                            self.level.shop.handle_event(event)
                        if self.level.tutorial.active:
                            self.level.tutorial.handle_event(event)
                            continue
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if not self.level.tutorial.active:
                            continue
                        self.level.tutorial.handle_event(event)
                        continue
                if not running:
                    break
                if self.game_state == 'intro':
                    self.intro.update(dt)
                    self.intro.draw()
                elif self.game_state == 'menu':
                    self.menu.run()
                else:
                    self.screen.fill(WATER_COLOR)
                    self.level.run()
                    pygame.display.update()
                self.clock.tick(FPS)
                await asyncio.sleep(0)
            except Exception as e:
                print(f'Error occurred: {e}')
                import traceback
                traceback.print_exc()
                running = False
        pygame.quit()


async def main():
    game = Game()
    await game.run()


if __name__ == '__main__':
    asyncio.run(main())
