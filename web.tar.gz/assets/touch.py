"""触屏虚拟摇杆与按钮。

桌面端默认不显示；一旦检测到触摸事件（手机 / 平板）就自动出现，
点一次左下摇杆移动、右下按钮攻击，右侧小按钮对应 武器 / 魔法切换 / 升级 / 商店 / 确认 / 关闭。

设计要点：
- 按钮动作尽量转换成「合成的按键事件」投进事件队列，这样菜单、商店、升级面板
  原有的键盘逻辑完全不用改；
- 移动和攻击是每帧轮询的状态，所以直接读摇杆状态，不走事件；
- 桌面用户按 T 也能开关，方便调试图标位置。
"""
import pygame

from settings import WIDTH, HEIGHT
from support import get_font

_touch_seen = False
_forced = False


def note_event(event):
    """记录这台设备是否有触摸能力（SDL 会用 touch 标记合成的鼠标事件）。"""
    global _touch_seen
    if _touch_seen:
        return
    if event.type in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
        _touch_seen = True
    elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
        if getattr(event, 'touch', False):
            _touch_seen = True


def toggle_forced():
    global _forced
    _forced = not _forced
    return visible()


def visible():
    return _touch_seen or _forced


class TouchControls:
    FINGER_EVENTS = (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION)

    def __init__(self, level):
        self.level = level
        self.display_surface = pygame.display.get_surface()
        self.font = get_font(20)
        self.font_small = get_font(16)
        self.dir = pygame.math.Vector2()
        self.attack_held = False
        self.magic_pressed = False
        self._move_id = None
        self._last_finger = -10000
        self._build_layout()

    # ---------- 布局 ----------
    def _build_layout(self):
        self.dpad_center = (170, 552)
        self.dpad_radius = 118
        self.knob_radius = 44
        self.buttons = [
            {'label': '攻击', 'center': (1128, 592), 'radius': 76, 'action': ('attack',), 'size': 24},
            {'label': '魔法', 'center': (996, 548), 'radius': 54, 'action': ('magic',), 'size': 20},
            {'label': '确认', 'center': (1000, 432), 'radius': 34, 'action': ('key', pygame.K_SPACE), 'size': 16},
            {'label': '关闭', 'center': (1000, 350), 'radius': 34, 'action': ('key', pygame.K_ESCAPE), 'size': 16},
            {'label': '升级', 'center': (1206, 470), 'radius': 29, 'action': ('key', pygame.K_m), 'size': 16},
            {'label': '商店', 'center': (1206, 404), 'radius': 29, 'action': ('key', pygame.K_g), 'size': 16},
            {'label': '武器', 'center': (1206, 338), 'radius': 29, 'action': ('key', pygame.K_q), 'size': 16},
            {'label': '魔换', 'center': (1206, 272), 'radius': 29, 'action': ('key', pygame.K_e), 'size': 16},
        ]

    def _pos(self, event):
        # 鼠标事件带 pos，触摸(FINGER)事件带 x/y，两种都要兼容
        pos = getattr(event, 'pos', None)
        if pos is None:
            pos = (getattr(event, 'x', 0), getattr(event, 'y', 0))
        x, y = pos
        if isinstance(x, float) and 0.0 <= x <= 1.0 and 0.0 <= y <= 1.0:
            return int(x * WIDTH), int(y * HEIGHT)
        return int(x), int(y)

    # ---------- 事件 ----------
    def handle_event(self, event):
        """返回 True 表示这次输入已被虚拟按键吃掉，主循环不用再处理。"""
        if not visible():
            return False

        is_finger = event.type in self.FINGER_EVENTS
        if is_finger:
            self._last_finger = pygame.time.get_ticks()
        elif getattr(event, 'touch', False):
            # 触摸会被 SDL 合成一份鼠标事件；刚处理过 FINGER 就丢掉这份重复的
            if pygame.time.get_ticks() - self._last_finger < 400:
                return True

        is_press = (event.type == pygame.FINGERDOWN) or (
            event.type == pygame.MOUSEBUTTONDOWN and getattr(event, 'button', 0) == 1)
        is_move = (event.type == pygame.FINGERMOTION) or (
            event.type == pygame.MOUSEMOTION and self._move_id is not None)
        is_release = (event.type == pygame.FINGERUP) or (
            event.type == pygame.MOUSEBUTTONUP and getattr(event, 'button', 0) == 1)

        if not (is_press or is_move or is_release):
            return False

        pos = self._pos(event)
        ident = getattr(event, 'finger_id', 0) if is_finger else 0

        if is_press:
            if self._in_dpad(pos) or self._move_id is not None:
                self._move_id = ident
                self._update_dir(pos)
                return True
            for button in self.buttons:
                if self._in_button(pos, button):
                    self._trigger(button['action'])
                    if button['action'][0] == 'attack':
                        self.attack_held = True
                    return True
            return False

        if is_move and self._move_id is not None and ident in (self._move_id, 0):
            self._update_dir(pos)
            return True

        if is_release:
            if self._move_id is not None and ident in (self._move_id, 0):
                self._move_id = None
                self.dir.update(0, 0)
                return True
            self.attack_held = False
        return False

    def _in_dpad(self, pos):
        cx, cy = self.dpad_center
        return (pos[0] - cx) ** 2 + (pos[1] - cy) ** 2 <= (self.dpad_radius + 26) ** 2
    def _update_dir(self, pos):
        cx, cy = self.dpad_center
        offset = pygame.math.Vector2(pos[0] - cx, pos[1] - cy)
        if offset.length() < self.dpad_radius * 0.22:      # 死区
            self.dir.update(0, 0)
            return
        self.dir = offset.normalize()
        if abs(self.dir.x) < 0.28:
            self.dir.x = 0
        if abs(self.dir.y) < 0.28:
            self.dir.y = 0
        if self.dir.length_squared() > 0:
            self.dir = self.dir.normalize()

    @staticmethod
    def _in_button(pos, button):
        cx, cy = button['center']
        return (pos[0] - cx) ** 2 + (pos[1] - cy) ** 2 <= (button['radius'] + 8) ** 2

    def _trigger(self, action):
        kind = action[0]
        if kind == 'attack':
            if self.level and self.level.player:
                self.level.player.trigger_attack()
            return
        if kind == 'magic':
            self.magic_pressed = True
            return
        if kind == 'key':
            pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=action[1], mod=0,
                                                 unicode='', scancode=0))

    # ---------- 每帧 ----------
    def update(self, player):
        if player is None:
            return
        player.virtual_dir = pygame.math.Vector2(self.dir)
        player.virtual_attack = self.attack_held
        player.virtual_magic = self.magic_pressed
        self.magic_pressed = False

    def draw(self):
        if not visible():
            return
        surface = self.display_surface
        self._draw_dpad(surface)
        for button in self.buttons:
            self._draw_button(surface, button)

    def _draw_dpad(self, surface):
        layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        pygame.draw.circle(layer, (16, 18, 28, 96), self.dpad_center, self.dpad_radius)
        pygame.draw.circle(layer, (255, 255, 255, 60), self.dpad_center, self.dpad_radius, 3)
        knob = (self.dpad_center[0] + int(self.dir.x * self.dpad_radius * 0.55),
                self.dpad_center[1] + int(self.dir.y * self.dpad_radius * 0.55))
        pygame.draw.circle(layer, (240, 240, 250, 130), knob, self.knob_radius)
        pygame.draw.circle(layer, (255, 255, 255, 90), knob, self.knob_radius, 2)
        surface.blit(layer, (0, 0))

    def _draw_button(self, surface, button):
        cx, cy = button['center']
        r = button['radius']
        active = button['action'][0] == 'attack' and self.attack_held
        layer = pygame.Surface((r * 2 + 8, r * 2 + 8), pygame.SRCALPHA)
        color = (255, 200, 60, 150) if active else (16, 18, 28, 96)
        border = (255, 220, 120, 200) if active else (255, 255, 255, 70)
        pygame.draw.circle(layer, color, (r + 4, r + 4), r)
        pygame.draw.circle(layer, border, (r + 4, r + 4), r, 3)
        font = self.font if button.get('size', 16) >= 20 else self.font_small
        text = font.render(button['label'], True, (235, 235, 245))
        surface.blit(layer, (cx - r - 4, cy - r - 4))
        surface.blit(text, text.get_rect(center=(cx, cy)))
