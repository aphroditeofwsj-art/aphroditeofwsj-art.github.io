from csv import reader
from os import walk
import pygame
import sys
from pathlib import Path
from functools import lru_cache

def get_resource_path():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS)
    if sys.platform == 'emscripten':
        return Path(__file__).resolve().parent
    return Path(__file__).resolve().parent.parent

RESOURCE_PATH = get_resource_path()

@lru_cache(maxsize=None)
def get_font(size):
    '''优先使用随包分发的 CJK 字体，保证浏览器内中文正常显示'''
    try:
        return pygame.font.Font(str(RESOURCE_PATH / 'graphics/font/cjk.otf'), size)
    except Exception:
        return pygame.font.SysFont('Microsoft YaHei', size)

def import_csv_layout(path):
    terrain_map = []
    full_path = RESOURCE_PATH / path
    with open(full_path) as level_map:
        layout = reader(level_map, delimiter=',')
        for row in layout:
            terrain_map.append(list(row))
        return terrain_map

def import_folder(path):
    surface_list = []
    full_base = RESOURCE_PATH / path
    for _, __, img_files in walk(full_base):
        for image in img_files:
            full_path = full_base / image
            image_surf = pygame.image.load(full_path).convert_alpha()
            surface_list.append(image_surf)
    return surface_list

