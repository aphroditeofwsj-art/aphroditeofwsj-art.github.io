from csv import reader
from os import walk
import pygame
import sys
from pathlib import Path
from functools import lru_cache

def get_resource_path():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS)
    if sys.platform == 'emscripten':
        return Path(__file__).resolve().parent
    return Path(__file__).resolve().parent.parent

RESOURCE_PATH = get_resource_path()


def _ci_candidates(parent: Path, name: str):
    '''在 parent 下按大小写不敏感的方式查找 name（浏览器 / Linux 文件系统区分大小写）'''
    try:
        for child in parent.iterdir():
            if child.name.lower() == name.lower():
                return child
    except OSError:
        pass
    return None


def resolve(path):
    '''把 'graphics/Grass' 这类路径解析成真实存在的路径。

    依次尝试：原样 -> 逐级大小写不敏感匹配 -> 空。
    找不到时返回 None，调用方可以安全降级，而不是抛异常把整个游戏打死。
    '''
    p = Path(path)
    if not p.is_absolute():
        p = RESOURCE_PATH / p
    if p.exists():
        return p
    # 逐级做大小写不敏感匹配
    cur = RESOURCE_PATH if not Path(path).is_absolute() else Path(p.anchor or '/')
    parts = Path(path).parts
    for part in parts:
        if part in ('', '.', '..'):
            continue
        nxt = cur / part
        if nxt.exists():
            cur = nxt
            continue
        found = _ci_candidates(cur, part)
        if found is None:
            return None
        cur = found
    return cur if cur.exists() else None


@lru_cache(maxsize=None)
def get_font(size):
    '''优先使用随包分发的 CJK 字体，保证浏览器内中文正常显示'''
    for name in ('graphics/font/cjk.otf', 'graphics/font/joystix.ttf'):
        fp = resolve(name)
        if fp is not None:
            try:
                return pygame.font.Font(str(fp), size)
            except Exception:
                continue
    for family in ('Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC', 'PingFang SC'):
        try:
            f = pygame.font.SysFont(family, size)
            if f is not None:
                return f
        except Exception:
            continue
    return pygame.font.Font(None, size)


def import_csv_layout(path):
    terrain_map = []
    full_path = resolve(path)
    if full_path is None:
        print(f'[asset] missing csv: {path}', flush=True)
        return terrain_map
    with open(full_path, encoding='utf-8', errors='replace') as level_map:
        layout = reader(level_map, delimiter=',')
        for row in layout:
            terrain_map.append(list(row))
    return terrain_map


def import_folder(path):
    '''读取目录下所有图片；任何一张读不出来都不能让游戏崩掉'''
    surface_list = []
    full_base = resolve(path)
    if full_base is None or not full_base.is_dir():
        print(f'[asset] missing folder: {path}', flush=True)
        return surface_list
    for root, _dirs, img_files in walk(full_base):
        for image in sorted(img_files):
            full_path = Path(root) / image
            try:
                image_surf = pygame.image.load(str(full_path)).convert_alpha()
            except Exception as e:
                print(f'[asset] skip {image}: {e}', flush=True)
                continue
            surface_list.append(image_surf)
    if not surface_list:
        print(f'[asset] empty folder: {path}', flush=True)
    return surface_list
