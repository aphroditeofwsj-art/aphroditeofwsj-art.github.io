import pygame
import math
from settings import *

class Fruit(pygame.sprite.Sprite):
    def __init__(self, pos, heal_amount, groups):
        super().__init__(groups)
        self.sprite_type = 'fruit'
        self.frames = []
        for i in range(4):
            surf = pygame.Surface((32, 32), pygame.SRCALPHA)
            pygame.draw.circle(surf, (220, 50, 50), (16, 18), 12)
            pygame.draw.circle(surf, (255, 150, 150), (12, 14), 4)
            pygame.draw.ellipse(surf, (80, 180, 80), (14, 4, 8, 6))
            pygame.draw.ellipse(surf, (120, 220, 120), (15, 5, 4, 3))
            pygame.draw.rect(surf, (100, 70, 40), pygame.Rect(15, 8, 3, 4))
            self.frames.append(surf)
            continue
        self.frame_index = 0
        self.animation_speed = 0.15
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect(center=pos)
        self.hitbox = self.rect.inflate(-8, -8)
        self.original_y = self.rect.y
        self.heal_amount = heal_amount
        self.bob_offset = 0
        self.bob_speed = 0.08
        self.bob_height = 4

    def animate(self):
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

    def update(self):
        self.animate()
        self.bob_offset += self.bob_speed
        self.rect.y = self.original_y + self.bob_height * math.sin(self.bob_offset)


