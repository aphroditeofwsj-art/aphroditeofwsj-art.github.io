import pygame
from settings import *
from support import import_folder


class Villager(pygame.sprite.Sprite):
    def __init__(self, pos, groups, name, dialogues):
        super().__init__(groups)
        self.sprite_type = 'villager'
        self.name = name
        self.dialogues = dialogues
        self.dialogue_index = 0
        self.import_villager_graphics()
        self.status = 'idle'
        self.frame_index = 0
        self.image = self.animations[self.status][self.frame_index]
        self.rect = self.image.get_rect(bottomleft=pos)
        self.hitbox = self.rect.inflate(-20, -20)
        self.interacting = False
        self.can_interact = True
        self.has_shop = name == '商人'

    def import_villager_graphics(self):
        self.animations = {'idle': [], 'walk': []}
        profession_sprites = {'商人': 'merchant', '铁匠': 'blacksmith', '药师': 'healer'}
        sprite_folder = profession_sprites.get(self.name, 'merchant')
        main_path = f'graphics/villagers/{sprite_folder}/'
        success = False
        try:
            for animation in self.animations.keys():
                full_path = main_path + animation
                self.animations[animation] = import_folder(full_path)
                if len(self.animations[animation]) > 0:
                    success = True
        except Exception:
            pass
        if not success or len(self.animations['idle']) == 0:
            self.create_default_graphics()

    def create_default_graphics(self):
        colors = {'商人': {'body': (139, 69, 19), 'head': (255, 228, 196), 'outfit': (80, 40, 120)}, '铁匠': {'body': (255, 228, 196), 'head': (139, 90, 43), 'outfit': (50, 50, 50)}, '药师': {'body': (255, 228, 196), 'head': (255, 255, 255), 'outfit': (34, 139, 34)}}
        c = colors.get(self.name, colors['商人'])
        for _ in range(4):
            surf = pygame.Surface((TILESIZE, TILESIZE * 1.5), pygame.SRCALPHA)
            pygame.draw.rect(surf, c['outfit'], (15, 50, 34, 45))
            pygame.draw.circle(surf, c['head'], (TILESIZE // 2, 30), 20)
            pygame.draw.circle(surf, (0, 0, 0), (TILESIZE // 2 - 6, 28), 3)
            pygame.draw.circle(surf, (0, 0, 0), (TILESIZE // 2 + 6, 28), 3)
            if self.name == '商人':
                pygame.draw.rect(surf, (255, 215, 0), (20, 55, 24, 8))
            elif self.name == '铁匠':
                pygame.draw.rect(surf, (100, 100, 100), (12, 45, 8, 30))
            elif self.name == '药师':
                pygame.draw.circle(surf, (0, 255, 0), (45, 60), 8)
            self.animations['idle'].append(surf)
            self.animations['walk'].append(surf)

    def get_dialogue(self):
        if self.dialogue_index < len(self.dialogues):
            return self.dialogues[self.dialogue_index]
        return None

    def next_dialogue(self):
        self.dialogue_index += 1
        if self.dialogue_index >= len(self.dialogues):
            self.dialogue_index = 0
            return False
        return True

    def reset_dialogue(self):
        self.dialogue_index = 0

    def update(self):
        self.frame_index += 0.1
        if self.frame_index >= len(self.animations[self.status]):
            self.frame_index = 0
        self.image = self.animations[self.status][int(self.frame_index)]


class VillagerManager:
    def __init__(self):
        self.villagers = pygame.sprite.Group()

    def create_villager(self, pos, groups, name, dialogues):
        return Villager(pos, groups, name, dialogues)
